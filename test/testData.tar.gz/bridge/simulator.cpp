#include "simulator.h"
#include <iostream>
#include <cmath>

using namespace std;

Simulator::Simulator(vector<Simpoint*> *p, vector<Link> *l):points(p), links(l)
{
}

void Simulator::run(float dt)
{
	const Vec2d g(0.0f, 10.0f);
	const float qdamp = 0.01f;
	const float ldamp = 0.025f;
	const float cdamp = 0.05f;
	const float dvmax = 0.01f;
	const float tmin = 0.001f;
	int iter=1;
	bool re;
	while(iter) {
		re = false;
		for(vector<Simpoint*>::iterator i = points->begin(); i != points->end(); i++)
			if((*i)->m && !(*i)->fixed) 
				(*i)->a = g;
			else
				(*i)->a = Vec2d(0.0f, 0.0f);
		
		for(vector<Link>::iterator i = links->begin(); i != links->end(); i++){
			Vec2d r = (*i).points[0]->r - (*i).points[1]->r;
			Vec2d F = r*((*i).D/r.abs()*(r.abs()-(*i).l)/(*i).l);
			if(!(*i).points[0]->fixed) (*i).points[0]->a -= F*(1/(*i).points[0]->m);
			if(!(*i).points[1]->fixed) (*i).points[1]->a += F*(1/(*i).points[1]->m);
		}
		
		for(vector<Simpoint*>::iterator i = points->begin(); i != points->end(); i++){
			(*i)->a -= (*i)->v * ((*i)->v.abs() * qdamp + ldamp + 1/(*i)->v.abs()*cdamp);
			if((((*i)->a * dt).abs() > dvmax) && (dt/2 > tmin)){
				iter *=  2;
				dt /= 2;
				re = true;
				break;
			}
		}
		
		if(!re){
			for(vector<Simpoint*>::iterator i = points->begin(); i != points->end(); i++){
				(*i)->v += (*i)->a * dt;
				(*i)->r += (*i)->v * dt;
			}
			iter--;
		}
	}
}
