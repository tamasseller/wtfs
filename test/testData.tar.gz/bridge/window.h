#ifndef WINDOW_H
#define WINDOW_H

#include <vector>
#include <GL/gl.h>

#include "simulator.h"

class Simulator;
class Simpoint;
using namespace std;

class Color{
	public:
		unsigned char r, g, b;
		Color(int _r, int _g, int _b):r(_r), g(_g), b(_b){}
		Color():r(128),g(128),b(128){}
		void set(){glColor4ub(r, g, b, 255);}
};

class Point {
	public:
		int x, y;
		Color c;
		Point():x(0),y(0){}
		Point(int _x, int _y, int r, int g, int b):x(_x),y(_y),c(r, g, b){}
		Point(int _x, int _y, Color _c):x(_x),y(_y),c(_c){}
		Point(int _x, int _y):x(_x),y(_y){}
		void push(){c.set(); glVertex2i(x, y);}
		Point operator +(const Point &o) {return Point(x+o.x, y+o.y, c);}
		Point operator -() {return Point(-x, -y);}
		Point operator -(Point o) {Point temp = -o; return *this + temp;}
		Point operator *(float o) {return Point (o*x, o*y);}
};

class Circle
{
	public:
		Point center;
		int radius;
		
		Circle(Point c, int r):center(c), radius(r){}
		Circle(int x, int y, int r):center(x, y), radius(r){}
		Circle(int x, int y, int rad, int r, int g, int b):center(x, y, r, g, b), radius(rad){}
};

class Rect
{
	public:
		Point topLeft, topRight, bottomLeft, bottomRight;
		Rect(Point a, Point b, Point c, Point d):topLeft(a), topRight(b), bottomLeft(c), bottomRight(d){}
		Rect(Point p, int w, int h){Rect(p.x, p.y, w, h);}
		Rect(int x, int y, int w, int h){
			*this = Rect(Point(x-w/2, y-h/2), Point(x+w/2, y-h/2), Point(x-w/2, y+h/2), Point(x+w/2, y+h/2));
		}
};

class Line
{
	public:
		Point endpoints[2];
		float w;
		Line(int x1, int y1, int x2, int y2, int r=128, int g=128, int b=128){
			endpoints[0] = Point(x1, y1, r, g, b);
			endpoints[1] = Point(x2, y2, r, g, b);
			w=1.0f;
		}
		Line &width(float f){
			w = f;
			return *this;
		}
};

class MainWindow{
	static int window; 
	static int selected;
	static bool drag;
	
	static const int ESCAPE;
	static const int Width;
	static const int Height;
	
	static Simulator* simulator;
	
	static void ReSizeGLScene(int, int);
	static void DrawGLScene();
	static void keyPressed(unsigned char, int, int);
	static void IdleFunc();
	static void entryFunc(int);
	static void motionFunc(int, int);
	static void mouseFunc(int, int, int, int);
	static void simplify();
	static void delpoint(int);
	static void dellink(int, int);
	static int findNearest(int x, int y);
	public:
		static vector <Circle> circles;
		static vector <Rect> rectangles;
		static vector <Line> lines;
		MainWindow(int *, char **);
		void run();
		void clearPrimBuffs();
};
#endif

