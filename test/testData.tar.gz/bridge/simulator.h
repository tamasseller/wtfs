#ifndef SIMULATOR_H
#define SIMULATOR_H

#include <vector>
#include <math.h>

#include "window.h"

class Circle;
class Line;

using namespace std;

class Vec2d {
	public:
		float x, y;
		float abs(){float l = sqrtf(x*x+y*y); return (l <= 0.000001)?0.000001:l;}
		Vec2d(float _x, float _y):x(_x), y(_y){}
		Vec2d operator +(const Vec2d &o) {return Vec2d(x+o.x, y+o.y);}
		Vec2d operator -() {return Vec2d(-x, -y);}
		Vec2d operator -(Vec2d o) {return Vec2d(x-o.x, y-o.y);}
		Vec2d operator *(float o) {return Vec2d (o*x, o*y);}
		Vec2d operator += (Vec2d o) {*this = *this + o; return *this;}
		Vec2d operator -= (Vec2d o) {*this = *this - o; return *this;}
};

class Simpoint{
	public:
	Vec2d r, v, a;
	float m;
	bool fixed;
	Simpoint(float x, float y, float _m): r(x, y), v(0.0f, 0.0f), a(0.0f, 0.0f), m(_m){if(!m) fixed = true;}
};

class Link {
	public:
		Link(Simpoint* a, Simpoint* b, float _D):l((a->r-b->r).abs()),D(_D){points[0] = a; points[1] = b;}
		Simpoint *points[2];
		float l;
		float D;
};

class Simulator {
	public:
		vector<Simpoint*> *points;
		vector<Link> *links;
		Simulator(vector<Simpoint*> *p, vector<Link> *l);
		
		void run(float);
};

#endif
