#include "window.h"

#include <sys/time.h>
#include <string.h>

#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include <iostream>

#include <unistd.h>
#include <math.h>

using namespace std;

const int MainWindow::ESCAPE = 27;
const int MainWindow::Width = 640;
const int MainWindow::Height = 480;
const int grid = 16;
int MainWindow::window=0;
vector <Circle> MainWindow::circles;
vector <Rect> MainWindow::rectangles;
vector <Line> MainWindow::lines;
Simulator *MainWindow::simulator = 0;
int MainWindow::selected = -1;
int other = -1;
bool MainWindow::drag = false;

bool running = false, del = false;
float mousex, mousey;

int timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1)
{
    long int diff = (t2->tv_usec + 1000000 * t2->tv_sec) - (t1->tv_usec + 1000000 * t1->tv_sec);
    result->tv_sec = diff / 1000000;
    result->tv_usec = diff % 1000000;

    return (diff<0);
}


void MainWindow::simplify()
{
	selected = -1;
	for(unsigned int i = 0; i < simulator->points->size(); i++) {
		for(unsigned int j = i+1; j < simulator->points->size(); j++) {
			if((simulator->points->at(i)->r - simulator->points->at(j)->r).abs() < 0.001f){
				Simpoint *from, *to;
				bool restart = false;
				if(simulator->points->at(i)->m){
					from = simulator->points->at(i);
					to = simulator->points->at(j);
					simulator->points->erase(simulator->points->begin()+i--);
					restart = true;
				}else{
					from = simulator->points->at(j);
					to = simulator->points->at(i);
					simulator->points->erase(simulator->points->begin()+j--);
				}
				
				for(unsigned int k = 0; k < simulator->links->size(); k++){
					bool ch=false;
					if(simulator->links->at(k).points[0] == from){
						simulator->links->at(k).points[0] = to;
						ch = true;
					}
					if(simulator->links->at(k).points[1] == from){
						if(ch)
							simulator->links->erase(simulator->links->begin()+k--);
							
						simulator->links->at(k).points[1] = to;
					}
				}
				
				if(restart)
					break;
			}	
		}
	}
	
	for(vector<Link>::iterator i = simulator->links->begin(); i != simulator->links->end(); i++)
		(*i) = Link((*i).points[0], (*i).points[1], (*i).D);
}

void MainWindow::delpoint(int n)
{
	Simpoint *p = simulator->points->at(n);
	simulator->points->erase(simulator->points->begin()+n);
	
	for(unsigned int i = 0; i < simulator->links->size(); i++)
		if( (simulator->links->at(i).points[0] == p) ||
			(simulator->links->at(i).points[1] == p))
			simulator->links->erase(simulator->links->begin()+i--);
}
void MainWindow::dellink(int aid, int bid)
{
	Simpoint* a = simulator->points->at(aid);
	Simpoint* b = simulator->points->at(bid);
	for(unsigned int i = 0; i< simulator->links->size(); i++){
		if((simulator->links->at(i).points[0] == a &&
			simulator->links->at(i).points[1] == b) ||
		   (simulator->links->at(i).points[0] == b &&
			simulator->links->at(i).points[1] == a)){
			simulator->links->erase(simulator->links->begin()+i);	
			return;
		}
	}
	
	bool aok = false, bok = false;
	for(unsigned int i = 0; i < simulator->links->size(); i++){
		if((simulator->links->at(i).points[0] == a) || (simulator->links->at(i).points[1] == a))
			aok = true;
		if((simulator->links->at(i).points[0] == b) || (simulator->links->at(i).points[1] == b))
			bok = true;
	}
	
	if(!aok)
		simulator->points->erase(simulator->points->begin()+aid);
		
	if(!bok)
		simulator->points->erase(simulator->points->begin()+bid);
}

int MainWindow::findNearest(int x, int y)
{
	float smallest=0.0f;
	float sel = -1;
	for(unsigned int i = 0; i < simulator->points->size(); i++)
		if((sel < 0) || ((Vec2d(x, y) - simulator->points->at(i)->r).abs() < smallest)){
			smallest = (Vec2d(x, y) - simulator->points->at(i)->r).abs();
			sel = i;
		}

	return sel;
}



void MainWindow::motionFunc(int x, int y)
{
	mousex = x;
	mousey = y;

	if(del)
		other = findNearest(x, y);
}

void MainWindow::entryFunc(int state)
{
}

void MainWindow::mouseFunc(int key, int state, int x, int y)
{
	mousex = x;
	mousey = y;

	if((key == GLUT_RIGHT_BUTTON) && (state == GLUT_DOWN)){
		if(!drag && !del)
			selected = findNearest(x, y);
	}
	
	if((key == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN)){
		if(del){			
			del = false;
			if(selected == other)
				delpoint(other);
			else
				dellink(selected, other);
			selected = -1;
			other = -1;
		}
		else{
			if(!drag && !running && (selected >= 0)){
				drag = true;
				simulator->points->push_back(new Simpoint(x, y, 1.0f));
				simulator->links->push_back(Link(simulator->points->at(selected), simulator->points->back(), 10000.0f));
				selected = simulator->points->size()-1;
			}
			else if(drag){
				if(selected >= 0) simulator->points->at(selected)->fixed = false;
				drag = false;			
				simplify();
			}
		}
	}
}

void MainWindow::keyPressed(unsigned char key, int x, int y) 
{
	usleep(100);
	if (key == ESCAPE){
		if(del){
			selected = -1;
			other = -1;
			del = false;
		}
		if(drag){
			delpoint(selected);
			selected = -1;
			drag = false;
		}
	}
	
	if(del || drag)
		return;
		
	if(key == 'q') { 
		glutDestroyWindow(window); 
		exit(0);                   
	}
	if (key == 'e' && !running){
		simulator->links->clear();
		for(unsigned int i=0; i < simulator->points->size(); i++)
			if(simulator->points->at(i)->m)
				simulator->points->erase(simulator->points->begin()+i--);
	}
	if (key == 'd' && !running && (selected >= 0)){
		del = true;
		other = findNearest(x, y);
	}
				
	if (key == 's'){
		static vector<Simpoint> saved;
		if(running){
			running = false;
			
			for(unsigned int i=0; i<simulator->points->size(); i++)
				*(simulator->points->at(i)) = saved[i];

		}else{
			running = true;

			simplify();
									
			saved.clear();
			for(unsigned int i=0; i<simulator->points->size(); i++)
				saved.push_back(*(simulator->points->at(i)));
		}
	}
}




MainWindow::MainWindow(int *argc, char **argv)
{
	glutInit(argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);  
	glutInitWindowSize(640, 480);  
	glutInitWindowPosition(0, 0);  
	window = glutCreateWindow("Yet another bridge builder game");
	
	glutDisplayFunc(DrawGLScene);  
	glutIdleFunc(IdleFunc);
	glutReshapeFunc(ReSizeGLScene);
	glutKeyboardFunc(keyPressed);
	glutPassiveMotionFunc(motionFunc);
	glutMouseFunc(mouseFunc);	
	glutEntryFunc(entryFunc);	
	
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_LINE_SMOOTH);
	glViewport(0, 0, Width, Height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, Width, Height, 0,-1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	Simpoint *point[] = {new Simpoint(5*grid, 25*grid, 0.0f), new Simpoint(35*grid, 25*grid, 0.0f)};
	static vector<Simpoint*> p (point, point + sizeof(point) / sizeof(Simpoint*));
	static vector<Link> l;
	simulator = new Simulator(&p, &l);
}

void MainWindow::ReSizeGLScene(int Width, int Height)
{
	if (Height==0)
		Height=1;
    
	glViewport(0, 0, Width, Height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, Width, Height, 0, -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void MainWindow::DrawGLScene()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	if(running){
		glClearColor(0.3f, 0.2f, 0.1f, 0.0f);
		
	}else
		glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	
	for(vector<Rect>::iterator i = rectangles.begin(); i != rectangles.end(); i++){
		glBegin(GL_QUADS);
		(*i).topLeft.push();
		(*i).bottomLeft.push();
		(*i).bottomRight.push();
		(*i).topRight.push();
		glEnd();
	}
	
	for(vector<Line>::iterator i = lines.begin(); i != lines.end(); i++){
		glLineWidth((*i).w);
		glBegin(GL_LINES);
		(*i).endpoints[0].push();
		(*i).endpoints[1].push();
		glEnd();
	}
	
	for(vector<Circle>::iterator i = circles.begin(); i != circles.end(); i++){
		glBegin(GL_TRIANGLE_FAN);
		(*i).center.push();
		for(float phi=0; phi<=2*3.1415926f+0.001f; phi += 2*3.1415926/32)
			((*i).center - Point(cosf(phi)*(float)((*i).radius), sinf(phi)*(float)((*i).radius))).push();
		glEnd();
	}

	glutSwapBuffers();
}


void MainWindow::IdleFunc() 
{
	static struct timeval last;
	struct timeval act, diff;
    gettimeofday(&act, NULL);
    timeval_subtract(&diff, &act, &last);
    memcpy(&last, &act, sizeof(struct timeval));
    
	if(drag && (selected >= 0)){
		simulator->points->at(selected)->r = Vec2d(floor(mousex/grid)*grid, floor(mousey/grid)*grid);
		simulator->points->at(selected)->v = Vec2d(0, 0);
		simulator->points->at(selected)->fixed = true;
	}
	
	if(running)
		simulator->run((diff.tv_sec+diff.tv_usec/1000000.0f)*5.0f);
	
	circles.clear();
	if(!running)
		for(vector<Simpoint*>::iterator i = simulator->points->begin(); i != simulator->points->end(); i++)
			if((*i)->m)
				circles.push_back(Circle((*i)->r.x, (*i)->r.y, 4));
			else
				circles.push_back(Circle((*i)->r.x, (*i)->r.y, 5, 255, 255, 255));
		
	lines.clear();
	for(vector<Link>::iterator i = simulator->links->begin(); i != simulator->links->end(); i++){
		int red;
		if(running) {
			float r = ((*i).points[0]->r-(*i).points[1]->r).abs();
			float l = (*i).l;
			red = atanf(((r-l)/l)*10.0f)/3.1415926/2*128;
		} else
			red = 0;
		lines.push_back(Line((*i).points[0]->r.x, (*i).points[0]->r.y, (*i).points[1]->r.x, (*i).points[1]->r.y, 128+red, 128-abs(red), 128-red).width(3.0f));
	}
	
	if(selected >= 0){
		if(del)
			circles[selected].center.c = Color(255, 128, 128);
		else
			circles[selected].center.c = Color(196, 196, 128);
	}
		
	if(del && (other >= 0))
		circles[other].center.c = Color(255, 0, 0);

	DrawGLScene();
}

void MainWindow::run()
{
	glutMainLoop();  
}
