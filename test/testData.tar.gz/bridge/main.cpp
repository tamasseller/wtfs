//#include "window.h"
#include "simulator.h"

int main(int argc, char **argv) 
{  
  MainWindow w(&argc, argv);
  
  w.run();
  
  return 1;
}

